<?php
    function generateAccountNumber() {
        return mt_rand(1000000000, 9999999999);
    }
