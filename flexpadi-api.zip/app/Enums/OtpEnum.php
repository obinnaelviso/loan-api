<?php

namespace App\Enums;

interface OtpEnum {

    const EMAIL_VERIFICATION = 'email-verification';
    const PHONE_VERIFICATION = 'phone-verification';

}
