<?php

namespace App\Enums;

interface TrnasactionEnum {

}
