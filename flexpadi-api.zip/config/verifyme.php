<?php
return [
    'url' => env('VERIFY_ME_URL'),
    'pk' => env('VERIFY_ME_PK'),
    'sk' => env('VERIFY_ME_SK'),
];
