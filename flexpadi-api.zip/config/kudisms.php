<?php
return [
    'url' => env('KUDISMS_URL'),
    'username' => env('KUDISMS_USERNAME'),
    'password' => env('KUDISMS_PASSWORD'),
];
