<?php

return [
    'expires_in_mins' => env('OTP_EXPIRES_IN_MINS', 15),
];
