<?php
return [
    'api' => env('DOMAIN_API'),
    'admin' => env('DOMAIN_ADMIN'),
];
