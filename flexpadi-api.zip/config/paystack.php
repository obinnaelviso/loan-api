<?php
return [
    'sk' => env('PAYSTACK_SK'),
    'pk' => env('PAYSTACK_PK'),
    'url' => env('PAYSTACK_URL')
];
